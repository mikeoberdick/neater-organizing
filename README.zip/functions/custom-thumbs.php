<?php
//Adding in the Featured Image functionality and adding in our custom sizes
add_image_size( 'small-blog', 550, 550, true);  //hard crop at 550x550
?>